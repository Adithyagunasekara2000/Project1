abstract class LibraryItem {
    private String title;
    private String itemID;
    private boolean checkedOut;

    public LibraryItem(String title, String itemID) {
        this.title = title;
        this.itemID = itemID;
        this.checkedOut = false;
    }

    public void checkOut() {
        checkedOut = true;
        System.out.println(title + " checked out.");
    }

    public void checkIn() {
        checkedOut = false;
        System.out.println(title + " checked in.");
    }

    public void displayItemDetails() {
        System.out.println("Title: " + title);
        System.out.println("Item ID: " + itemID);
        System.out.println("Status: " + (checkedOut ? "Checked Out" : "Available"));
    }
}