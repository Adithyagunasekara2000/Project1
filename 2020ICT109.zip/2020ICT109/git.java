abstract class Libraryitem()
{
	private String title;
	private String itemID;
	
	public Libraryitem(String title,String)
	{
		this.title=title;
		this.itemID=itemID;
	}
	
	public CheckOut()
	{
	}
	
	public Checkin(){
	}
	
	
	
	
	void displayItemDetails()
	{
		System.out.println("Title:"+itemID);
		System.out.println("Item ID:"+itemID);
		System.out.println("Status:"+(checkedOut? "Checked out":"Available"));
	}
}
	
	